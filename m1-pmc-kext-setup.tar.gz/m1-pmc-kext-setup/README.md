# Repo contents

* `timer` - contains the kext code and property list for the kext
* `instruction-images` - contains the images to be linked to in the instructions below
* `timer.xcodeproj` - xcode stuff ??

# Tested Setup
All the code of this repository was tested on a bare-metal Apple Mac
mini (Late 2020) with Apple Silicon, running **macOS Big Sur
11.2**. We do not guarantee that our code works on other setups.

# Credit and some notes

Most of this code (probably all of it minus some minor changes) comes
from [dougallj](https://github.com/dougallj/applecpu)'s applecpu timer
hacks and kernel extension code. The instructions here for getting the
kext up and running are compiled from a few places that have been
linked with a few clarifications for pain points we ran into. Even
with this process, getting kexts running on macOS feels random, and
after days of running this process over and over, it just finally
worked, so YMMV in this setup by *a lot*. 

# Getting the kext up and running

1. If you haven't modified the kext, skip this step. Follow all of the instructions from [here](http://www.robertopasini.com/index.php/2-uncategorised/624-osx-kernel-extension-programming). Do everything up until the section "Prepare the Kernel Extension for Loading" since these instructions are out of date.

2. Open the project in xcode. 

3. Make sure your property list looks like mine:

![Property list setting picture](/instruction-images/plist.png)

4. Make sure your build settings look like mine:

![Build settings picture](/instruction-images/buildsettings.png)

5. Make sure your certificate settings look like mine. Unfortunately,
   you will have to have an Apple/iTunes ID. If you don't
   already have a cert, then you'll have to make one, but this can
   all be done in the same settings window through xcode. If you
   don't have a developer account, RIP. It took me 3 weeks to get
   Apple to verify my Apple ID to get developer status or whatever
   they want to call it. The definition of disabling SIP from step 9
   makes it seem like you won't need a cert for testing kexts locally,
   but I couldn't get it to load until I at least did this and disabled
   SIP.

![Certificate settings picture](/instruction-images/signing.png)

6. Build the project for Debug mode. The shortcut for me is Command+B, or
you can do `Product > Build`. You can verify that your kext was signed
for local testing by running `$ codesign -d --extract-certificates ./timer.kext`
and checking for `codesign[\d]` in your working dir.

7. Reboot into startup recovery mode (shutdown the mac, turn it back
on by holding down the power button until the alternative boot
options come up)

8. Open up terminal

9. Disable system integrity protection: `$ csrutil disable` followed by however many `y`s

10. Reboot. `$ reboot`

11. Find wherever the debug build kext was put by xcode. Mine was located at
`~/Library/Developer/Xcode/DerivedData/timer-bjautuewlweomjdrmtygyzitpjid/Build/Products/Debug/`

12. Change directories to this dir (I did `$ cd ~/Library/Developer/Xcode/DerivedData/timer-bjautuewlweomjdrmtygyzitpjid/Build/Products/Debug/`)

13. Copy the timer kext (i.e., the `timer.kext` dir located in the aforementioned dir) to `/Library/Extensions/` as root. I did `$ sudo cp -r timer.kext /Library/Extensions`.

14. Make sure that the access permissions are 755, and the owner and group of the copied dir is `root:wheel`. I only had to do `$ sudo chgrp -R 0 timer.kext`.

After this, my `/Library/Extensions/` dir looked like this after running `ls -alh`:

```
☁  Extensions  ls -alh
total 0
drwxr-xr-x   6 root  wheel   192B May 26 16:49 .
drwxr-xr-x  64 root  wheel   2.0K May 19 08:43 ..
drwxr-xr-x   3 root  wheel    96B Jan 25 03:56 HighPointIOP.kext
drwxr-xr-x   3 root  wheel    96B Jan 25 03:56 HighPointRR.kext
drwxr-xr-x   3 root  wheel    96B Jan 25 03:56 SoftRAID.kext
drwxr-xr-x   3 root  wheel    96B May 26 16:49 timer.kext
```

15. After you copied the kext to the extensions dir, then you should've had a pop up that says you have to approve the kext in the `Security and Privacy` settings in systems preferences. Do this, hit allow on it, it'll ask you to restart which you should. If you did not get this prompt in `Security and Privacy` (I did not the first time I tried), then you will need to follow the installation instructions listed [here](https://github.com/saagarjha/TSOEnabler). Note: those instructions say things like 'After that try installing the kernel extension again.'; this corresponds to steps 12 through 17 that I have listed here.

16. After the restart, `$ cd /Library/Extensions`

17. `$ sudo kmutil load -p timer.kext`. If all went well, you'll have to enter your password for the sudo, but other than that, there will be no kernel panic or output from the command.

18. To verify the kext loaded, you can do `$ kmutil showloaded` or `$ log show --last 5m | grep -E 'TIMER START'`

