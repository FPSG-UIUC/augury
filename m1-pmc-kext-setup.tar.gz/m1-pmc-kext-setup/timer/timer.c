//
//  timer.c
//  timer
//
//  Created by archm1 on 5/19/21.
//  Credit to dougallj for writing most of this kext for enabling
//  the PMC in usermode.
//  https://github.com/dougallj/applecpu/tree/main/timer-hacks
//

#include <mach/mach_types.h>
#include <sys/systm.h>
#include <os/log.h>
#include <mach/mach_types.h>
#include <sys/systm.h>
#include <sys/types.h>
#include <sys/sysctl.h>

#define SREG_PMCR0 "S3_1_c15_c0_0"
#define SREG_PMCR1 "S3_1_c15_c1_0"

#define SREG_PMESR0 "S3_1_c15_c5_0"
#define SREG_PMESR1 "S3_1_c15_c6_0"

#define SREG_PMC0 "S3_2_c15_c0_0"
#define SREG_PMC1 "S3_2_c15_c1_0"
#define SREG_PMC2 "S3_2_c15_c2_0"
#define SREG_PMC3 "S3_2_c15_c3_0"
#define SREG_PMC4 "S3_2_c15_c4_0"
#define SREG_PMC5 "S3_2_c15_c5_0"
#define SREG_PMC6 "S3_2_c15_c6_0"
#define SREG_PMC7 "S3_2_c15_c7_0"
#define SREG_PMC8 "S3_2_c15_c9_0"
#define SREG_PMC9 "S3_2_c15_c10_0"

#define SREG_WRITE(SR, V) __asm__ volatile("msr " SR ", %0 ; isb" : : "r"(V))
#define SREG_READ(SR)                                                          \
  ({                                                                           \
    uint64_t VAL;                                                              \
    __asm__ volatile("mrs %0, " SR : "=r"(VAL));                               \
    VAL;                                                                       \
  })


kern_return_t timer_start(kmod_info_t * ki, void *d);
kern_return_t timer_stop(kmod_info_t *ki, void *d);
void log_current_el(void);
void log_current_PMUSERENR(void);

void log_current_el(void)
{
    os_log(OS_LOG_DEFAULT, "arch.m1.timer START log_current_el");
    uint64_t el = 17;
    __asm__ volatile(
        "mrs %0, CurrentEL\n\t"
        : "=r" (el)
        :
        :
    );
    os_log(OS_LOG_DEFAULT, "raw EL = %llu\n", el);
    os_log(OS_LOG_DEFAULT, "actual EL = %llu\n", el >> 2);
    os_log(OS_LOG_DEFAULT, "arch.m1.timer END log_current_el");
}

void log_current_PMUSERENR(void)
{
    os_log(OS_LOG_DEFAULT, "arch.m1.timer START log_current_PMUSERENR");
    uint64_t reg_contents = 0;
    os_log(OS_LOG_DEFAULT, "arch.m1.timer STARTING PMUSERENR_EL0 read");
    os_log(OS_LOG_DEFAULT, "reg_contents are %llu\n", reg_contents);
    __asm__ volatile(
        "mrs %0, PMUSERENR_EL0\n\t"
        : "=r" (reg_contents)
        :
        :
    );
    uint64_t nonreserved_bitmask = 0b1111;
    reg_contents &= nonreserved_bitmask;
    os_log(OS_LOG_DEFAULT, "PMUSERENR_EL0 = %llu\n", reg_contents);
    os_log(OS_LOG_DEFAULT, "arch.m1.timer END log_current_PMUSERENR");
}

void enable_PMUSERENR(void)
{
    os_log(OS_LOG_DEFAULT, "arch.m1.timer START enable_PMUSERENR");
    uint64_t reg_contents = 0b1101; // ER, CR, EN enable
    os_log(OS_LOG_DEFAULT, "arch.m1.timer STARTING PMUSERENR_EL0 write");
    os_log(OS_LOG_DEFAULT, "reg_contents are %#llx\n", reg_contents);
    __asm__ volatile(
        "msr PMUSERENR_EL0, %0\n\t"
        :
        : "r" (reg_contents)
        :
    );
    os_log(OS_LOG_DEFAULT, "arch.m1.timer END enable_PMUSERENR");
}

void log_pmu_ctrls(void)
{
    os_log(OS_LOG_DEFAULT, "read pmcrs start\n");
    uint64_t reg_contents;
    // check pmcr0
    __asm__ volatile(
        "mrs %0, S3_1_C15_C0_0\n\t"
        : "=r" (reg_contents)
        :
        :
    );
    os_log(OS_LOG_DEFAULT, "pmcr0 %#llx\n", reg_contents);
    reg_contents = 0;
    
    // check pmcr1
    __asm__ volatile(
        "mrs %0, S3_1_C15_C1_0\n\t"
        : "=r" (reg_contents)
        :
        :
    );
    os_log(OS_LOG_DEFAULT, "pmcr1 %#llx\n", reg_contents);
    reg_contents = 0;
    
    // check pmesr0
    __asm__ volatile(
        "mrs %0, S3_1_C15_C5_0\n\t"
        : "=r" (reg_contents)
        :
        :
    );
    os_log(OS_LOG_DEFAULT, "pmesr0 %#llx\n", reg_contents);
    reg_contents = 0;
    
    // check pmesr1
    __asm__ volatile(
        "mrs %0, S3_1_C15_C6_0\n\t"
        : "=r" (reg_contents)
        :
        :
    );
    os_log(OS_LOG_DEFAULT, "pmesr1 %#llx\n", reg_contents);
    os_log(OS_LOG_DEFAULT, "read pmcrs end\n");
}

static int sysctl_pmesr0 SYSCTL_HANDLER_ARGS {
  uint64_t in = -1;
  int error = SYSCTL_IN(req, &in, sizeof(in));

  if (!error && req->newptr) {
    printf("PMCKext2: pmesr1 = %llx\n", in);
    SREG_WRITE(SREG_PMESR0, in);
  } else if (!error) {
    printf("PMCKext2: read pmesr1\n");
    uint64_t out = SREG_READ(SREG_PMESR0);
    error = SYSCTL_OUT(req, &out, sizeof(out));
  }

  if (error) {
    printf("PMCKext2: sysctl_pmesr0 failed with error %d\n", error);
  }

  return error;
}

SYSCTL_PROC(_kern, OID_AUTO, pmesr0,
            CTLTYPE_QUAD | CTLFLAG_RW | CTLFLAG_ANYBODY, NULL, 0,
            &sysctl_pmesr0, "I", "pmesr0");

static int sysctl_pmesr1 SYSCTL_HANDLER_ARGS {
  uint64_t in = -1;
  int error = SYSCTL_IN(req, &in, sizeof(in));

  if (!error && req->newptr) {
    printf("PMCKext2: pmesr1 = %llx\n", in);
    SREG_WRITE(SREG_PMESR1, in);
  } else if (!error) {
    printf("PMCKext2: read pmesr1\n");
    uint64_t out = SREG_READ(SREG_PMESR1);
    error = SYSCTL_OUT(req, &out, sizeof(out));
  }

  if (error) {
    printf("PMCKext2: sysctl_pmesr1 failed with error %d\n", error);
  }

  return error;
}

SYSCTL_PROC(_kern, OID_AUTO, pmesr1,
            CTLTYPE_QUAD | CTLFLAG_RW | CTLFLAG_ANYBODY, NULL, 0,
            &sysctl_pmesr1, "I", "pmesr1");

static int sysctl_pmcr0 SYSCTL_HANDLER_ARGS {
  uint64_t in = -1;
  int error = SYSCTL_IN(req, &in, sizeof(in));

  if (!error && req->newptr) {
    printf("PMCKext2: pmcr0 = %llx\n", in);
    SREG_WRITE(SREG_PMCR0, in);
  } else if (!error) {
    printf("PMCKext2: read pmcr0\n");
    uint64_t out = SREG_READ(SREG_PMCR0);
    error = SYSCTL_OUT(req, &out, sizeof(out));
  }

  if (error) {
    printf("PMCKext2: sysctl_pmcr0 failed with error %d\n", error);
  }

  return error;
}

SYSCTL_PROC(_kern, OID_AUTO, pmcr0, CTLTYPE_QUAD | CTLFLAG_RW | CTLFLAG_ANYBODY,
            NULL, 0, &sysctl_pmcr0, "I", "pmcr0");

static int sysctl_pmcr1 SYSCTL_HANDLER_ARGS {
  uint64_t in = -1;
  int error = SYSCTL_IN(req, &in, sizeof(in));

  if (!error && req->newptr) {
    printf("PMCKext2: pmcr1 = %llx\n", in);
    SREG_WRITE(SREG_PMCR1, in);
  } else if (!error) {
    printf("PMCKext2: read pmcr1\n");
    uint64_t out = SREG_READ(SREG_PMCR1);
    error = SYSCTL_OUT(req, &out, sizeof(out));
  }

  if (error) {
    printf("PMCKext2: sysctl_pmcr1 failed with error %d\n", error);
  }

  return error;
}

SYSCTL_PROC(_kern, OID_AUTO, pmcr1, CTLTYPE_QUAD | CTLFLAG_RW | CTLFLAG_ANYBODY,
            NULL, 0, &sysctl_pmcr1, "I", "pmcr1");

kern_return_t timer_start(kmod_info_t * ki, void *d)
{
    os_log(OS_LOG_DEFAULT, "TIMER START\n");
    log_current_el();
    log_pmu_ctrls();
    os_log(OS_LOG_DEFAULT, "registering sysctl handlers\n");
    sysctl_register_oid(&sysctl__kern_pmesr0);
    sysctl_register_oid(&sysctl__kern_pmesr1);
    sysctl_register_oid(&sysctl__kern_pmcr0);
    sysctl_register_oid(&sysctl__kern_pmcr1);
    os_log(OS_LOG_DEFAULT, "finished registering sysctl handlers\n");
    return KERN_SUCCESS;
}

kern_return_t timer_stop(kmod_info_t *ki, void *d)
{
    os_log(OS_LOG_DEFAULT, "TIMER STOP\n");
    os_log(OS_LOG_DEFAULT, "un-registering sysctl handlers\n");
    sysctl_unregister_oid(&sysctl__kern_pmesr0);
    sysctl_unregister_oid(&sysctl__kern_pmesr1);
    sysctl_unregister_oid(&sysctl__kern_pmcr0);
    sysctl_unregister_oid(&sysctl__kern_pmcr1);
    os_log(OS_LOG_DEFAULT, "finished un-registering sysctl handlers\n");
    return KERN_SUCCESS;
}

/*
 kernel: (timer) TIMER START
 2021-05-28 11:42:43.440206-0700 0xfdc      Default     0x0                  0      0    kernel: (timer) arch.m1.timer START log_current_el
 2021-05-28 11:42:43.440207-0700 0xfdc      Default     0x0                  0      0    kernel: (timer) raw EL = 8
 2021-05-28 11:42:43.440207-0700 0xfdc      Default     0x0                  0      0    kernel: (timer) actual EL = 2
 2021-05-28 11:42:43.440208-0700 0xfdc      Default     0x0                  0      0    kernel: (timer) arch.m1.timer END log_current_el
 2021-05-28 11:42:43.440208-0700 0xfdc      Default     0x0                  0      0    kernel: (timer) read pmcrs start
 2021-05-28 11:42:43.440208-0700 0xfdc      Default     0x0                  0      0    kernel: (timer) pmcr0 0x3403
 2021-05-28 11:42:43.440209-0700 0xfdc      Default     0x0                  0      0    kernel: (timer) pmcr1 0x30300
 2021-05-28 11:42:43.440209-0700 0xfdc      Default     0x0                  0      0    kernel: (timer) pmesr0 0
 2021-05-28 11:42:43.440209-0700 0xfdc      Default     0x0                  0      0    kernel: (timer) pmesr1 0
 2021-05-28 11:42:43.440209-0700 0xfdc      Default     0x0                  0      0    kernel: (timer) read pmcrs end
 */
